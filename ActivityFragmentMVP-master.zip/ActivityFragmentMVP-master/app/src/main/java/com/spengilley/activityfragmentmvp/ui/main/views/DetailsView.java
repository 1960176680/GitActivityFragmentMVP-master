package com.spengilley.activityfragmentmvp.ui.main.views;


public interface DetailsView {

    public void showDetails(String details);
    public void finish();

}
