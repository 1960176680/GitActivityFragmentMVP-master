package com.spengilley.activityfragmentmvp.ui.common;

public interface BaseFragmentPresenter<T> {
    void init(T view);
}
