package com.spengilley.activityfragmentmvp.ui.main.presenters;


public interface MainPresenter {

    public void getImaginaryString();
}
