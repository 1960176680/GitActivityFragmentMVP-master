package com.spengilley.activityfragmentmvp.ui.main.views;


public interface IntroView {

    public void loadDetailsFragment();
}
