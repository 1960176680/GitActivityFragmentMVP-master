package com.spengilley.activityfragmentmvp.ui.main;

/**
 * Created by stephen pengilley on 29/06/2014.
 * Used by Fragments to communicate with MainActivity
 */
public interface FragmentCallback {

    public void loadDetailFragment();
    public void finishProcess();
}
